Óscar Pinto y Luis Cárabe, grupo 1401, pareja 2

Notas de implementación: 
*Solo añadimos transiciones que tengan al menos un estado final, en caso contrario, no es necesario crear una transición vacía, ya que nuestra función transitar lo tiene en cuenta en el momento de analizar los símbolos y buscar las transiciones. 
*prueba_afnd1.c es la prueba de nuestras funciones proporcionada por el enunciado, prueba_afnd2.c es una prueba propia para probar casos no cubiertos en el anterior.